<?php 
require_once "cliente.php";
//cliente::BusquedaCliente("Lanus");
cliente::BusquedaCliente($_GET["localidad"]);

?>