<?php 
require_once "helado.php";
Helado::ListadoDeImagenes($_GET["opcion"]);
//Helado::ListadoDeImagenes("borradas");

?>