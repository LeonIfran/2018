<?php 
require_once "cliente.php";
cliente::TraerMasVentas()

?>