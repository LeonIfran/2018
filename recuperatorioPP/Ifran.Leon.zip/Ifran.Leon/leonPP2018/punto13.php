<?php 
require_once "cliente.php";
cliente::TraerMasVentasConFoto();

?>