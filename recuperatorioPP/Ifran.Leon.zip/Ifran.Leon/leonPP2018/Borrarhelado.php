<?php 
include_once "Helado.php";
Helado::BorrarHelado($_POST["sabor"],$_POST["tipo"]);
?>