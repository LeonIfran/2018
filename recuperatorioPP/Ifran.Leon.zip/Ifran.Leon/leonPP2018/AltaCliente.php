<?php 
require_once "cliente.php";
$micliente = new cliente($_POST["id"],$_POST["nombre"],$_POST["localidad"]);
cliente::GuardarCliente($micliente);
//echo var_dump(cliente::TraerClientes());
//echo var_dump(cliente::TraerMasVentas());
//cliente::TraerMasVentas()
?>