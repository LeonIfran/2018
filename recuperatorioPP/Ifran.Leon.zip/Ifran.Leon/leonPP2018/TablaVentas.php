<?php 
/* 5- (2pt.) TablaVentas.php, puede recibir datos de la venta  como el email, el sabor o nada (traer todos los 
registros) para hacer una busqueda, y retorna una tabla con: (la imagen y todos sus datos ) */  
require_once "venta.php";
Venta::Busqueda($_GET["mail"],$_GET["sabor"]);
//Venta::Busqueda("leo@bm4u.net","");

?>