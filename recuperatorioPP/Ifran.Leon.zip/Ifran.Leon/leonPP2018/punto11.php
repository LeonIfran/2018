<?php 
require_once "cliente.php";
$micliente = new cliente($_POST["id"],$_POST["nombre"],$_POST["localidad"]);
cliente::GuardarCliente($micliente);
cliente::GuardarImagen($micliente);
?>