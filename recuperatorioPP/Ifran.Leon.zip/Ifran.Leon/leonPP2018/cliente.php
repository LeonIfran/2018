<?php
/* 9- Agregar una entidad cliente( id, nombre, localidad), 
en la venta agregar el id del cliente que realizo la compra. */
require_once "venta.php";
class Cliente
{
    private $_id;
    private $_nombre;
    private $_localidad;

    #region getters y setters
    public function getId()
    {
        return $this->_id;
    }
    public function getNombre()
    {
        return $this->_nombre;
    }
    public function getLocalidad()
    {
        return $this->_localidad;
    }

    public function SetId($value)
    {
        $this->_id = $value;
    }

    public function SetNombre($value)
    {
        $this->_nombre = $value;
    }

    public function SetLocalidad($value)
    {
        $this->_localidad = $value;
    }

    public function __construct($id,$nombre,$loc)
    {
        $this->_id = $id;
        $this->_nombre = $nombre;
        $this->_localidad = $loc;
    }

    public function ToString()
    {
        return $this->getId()." - ".$this->getNombre()." - ".$this->getLocalidad();
    }
    public static function GuardarCliente($obj)
    {
        if (!($recurso=fopen("./archivos/Clientes.txt","a"))) 
        {
            echo "error no se pudo guardar<br>";
            break;
        }
        else 
        {
            fwrite($recurso,$obj->ToString()."\r\n");
            fclose($recurso);
        }
    }

    public static function GuardarImagen($obj)
    {
    /* 11- Al dar de alta el cliente, se le debe agregar una foto con el “id+nombre.png”. */
    $fName = $obj->getId()."_".$obj->getNombre().".png";

        if (!move_uploaded_file($_FILES["imagen"]["tmp_name"],"./ImagenesDelCliente/".$fName)) 
        {
            echo "error al guardar el archivo<br>";
        }
        else
        {
            echo "Archivo guardado como $fName";
        }
    }
    

    public static function TraerClientes()
    {
        $arrClientes=array();
        $strAux;
        $ClienteAux;
        $recurso = fopen("./archivos/Clientes.txt","r");
        
        if ($recurso!=FALSE) 
        {
            while (!feof($recurso)) 
            {
                $strAux = trim(fgets($recurso));
                $strAux = explode(" - ",$strAux);
                if ($strAux[0]!='') 
                {
                    $ClienteAux = $strAux;
                    //$ClienteAux = new Cliente($strAux[0],$strAux[1],$strAux[2],$strAux[3]);
                    array_push($arrClientes,$ClienteAux);
                }
            }
        }
        return $arrClientes;
    }

    public static function TraerMasVentas()
    {
        $arrVentas = Venta::TraerVentas();
        //$arrMas = array_count_values($arrVentas);
        $arrIds=array();
        foreach ($arrVentas as $key => $value) //traigo las ventas con ID
        {
            if (!empty($value[4])) 
            {
                array_push($arrIds,$value[4]);//guardo las ventas en un array
            }
           
        }
        $arrCuenta = array_count_values($arrIds);//cuento las ocurrencias
        arsort($arrCuenta);//Ascending Sort
        
        $popular = array_slice(array_keys($arrCuenta), 0, 1, true);

        //ahora traigo la ciudad y nombre del cliente
        $arrClientes = Self::TraerClientes();
        foreach ($arrClientes as $key => $value) 
        {
            if ($value[0]==$popular[0]) 
            {
                echo "El cliente: ". $value[1]." localidad: ".$value[2]." Realizo mas compras";
                return $value[0]."_".$value[1];
                //break;
            }
        }

    }
    public static function TraerMasVentasConFoto()
    {
        $fName = Self::TraerMasVentas().".png";
        $ruta = "./ImagenesDelCliente/".$fName;
        //echo $fName."<br>".$ruta;
        echo "<br><img src='{$ruta}' width='150px' height='150px'>";
    }    
    public static function BusquedaCliente($dato)
    {
    //12- Listar por GET el listado usuarios filtrados por localidad.
    $arrClientes = Self::TraerClientes();
    $arrMostrar = array();
    foreach ($arrClientes as $value) 
    {
        if (array_search($dato,$value)!==FALSE) 
        {
            array_push($arrMostrar,$value);
        }
    }
    //return $arrMostrar;
    echo "<h1>Mostrando Localidad: $dato<h1>";
    Cliente::TablaClientes($arrMostrar);
    }

    public static function TablaClientes($arrClientes)
    {
        $tabla = "<table border=1>
        <tbody>
            <thead>
                <th>ID</th>
                <th>Nombre</th>
                <th>Localidad</th>
            
            </thead>";
        foreach ($arrClientes as $value) 
        {

            $tabla=$tabla."<tr>
            <td>$value[0]</td>
            <td>$value[1]</td>
            <td>$value[2]</td>";
            $tabla=$tabla."</tr>";
        }
        $tabla=$tabla."</tbody></table>";
        echo $tabla;
    }
    #endregion
}

?>